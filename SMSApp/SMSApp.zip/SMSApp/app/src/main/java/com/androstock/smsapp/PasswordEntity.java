package com.androstock.smsapp;




import android.arch.lifecycle.ViewModelProviders;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class PasswordEntity extends AppCompatActivity {

    public messageViewModel nvm;
    Button btn_encrypt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_entity);
        nvm= ViewModelProviders.of(this).get(messageViewModel.class);
        //nvm.insert(new User("username","text","id"));

    }
}
