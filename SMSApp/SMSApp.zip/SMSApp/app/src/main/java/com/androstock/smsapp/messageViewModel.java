package com.androstock.smsapp;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

public class messageViewModel extends AndroidViewModel {
    public messageDao notedao;
    public messageRoomDatabase database;


    public messageViewModel(@NonNull Application application) {
        super(application);
        database=messageRoomDatabase.getDatabase(application);
        notedao=database.notDao();
    }
    public void insert(Message user){
        new InsertAsyncTask(notedao).execute(user);
    }
    @Override
    protected void onCleared()
    {
        super.onCleared();
    }


    private class InsertAsyncTask extends AsyncTask<Message,Void,Void> {

        messageDao mnotedao;

        public InsertAsyncTask(messageDao mnotedao) {
            this.mnotedao = mnotedao;
        }

        @Override
        protected Void doInBackground(Message... users) {
            mnotedao.insert(users[0]);
            return null;
        }
    }

}
