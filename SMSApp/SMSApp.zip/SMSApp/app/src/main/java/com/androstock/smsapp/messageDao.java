package com.androstock.smsapp;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;

@Dao
public interface messageDao {

    @Insert
    void insert(Message msg);
}
