package com.androstock.smsapp;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

public abstract class messageRoomDatabase extends RoomDatabase {
    public abstract messageDao notDao();

    public static volatile messageRoomDatabase noteRoomInstance;

    public static messageRoomDatabase getDatabase(final Context context)
    {
        if(noteRoomInstance==null)
        {
            synchronized (messageRoomDatabase.class){
                if(noteRoomInstance==null){
                    noteRoomInstance= Room.databaseBuilder(context.getApplicationContext(),messageRoomDatabase.class,"message_database").build();
                }
            }
        }
        return noteRoomInstance;
    }
}
